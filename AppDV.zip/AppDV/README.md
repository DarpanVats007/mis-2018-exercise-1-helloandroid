Mobile Information Systems SoSe2018
===========================================
Exercise 1:
119188: Darpan Vats
118976: Dixith Pinjari
