package com.example.dude.appdv;

import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.test.AndroidTestRunner;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.w3c.dom.Document;

import java.io.IOException;

import static com.example.dude.appdv.R.id.tex1;
import static com.example.dude.appdv.R.id.but1;
import static com.example.dude.appdv.R.id.URLinput;



public class MainActivity extends AppCompatActivity {

    TextView text1;
    EditText inputURL;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputURL=(EditText)findViewById (R.id.URLinput);

        text1=(TextView)findViewById (tex1);
        text1.setMovementMethod (new ScrollingMovementMethod ());

        Button but= (Button)findViewById (R.id.but1);
        inputURL=(EditText)findViewById (R.id.URLinput);
        but.setOnClickListener (new View.OnClickListener () {

            @Override
            public void onClick(View v) {


                new doit ().execute ();

                showToast ("connecting");



            }
        });

    }

    private void showToast(String text){

        Toast.makeText (MainActivity.this, text, Toast.LENGTH_LONG).show ();
    }



    public class doit extends AsyncTask<Void,Void,Void> {

String words;
EditText inputURL;
String webPage;

        @Override
        protected Void doInBackground(Void... voids) {

            inputURL=(EditText)findViewById (R.id.URLinput);

            try {

                // HTML code

                String str = inputURL.getText ().toString ();

                String webPage = str;

                String html = Jsoup.connect(webPage).get().html();

                System.out.println(html);

                words= html;

                // HTML code end

            }

            catch (IOException e) {
                e.printStackTrace ();
                 showToast ("Cannot find the URL");
            }

            catch (Exception e) {

                e.printStackTrace ();
                showToast ("cannot connect to the server");
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute (aVoid);

            text1.setText (words);

        }
    }


}
